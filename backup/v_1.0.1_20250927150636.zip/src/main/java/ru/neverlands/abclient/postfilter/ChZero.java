package ru.neverlands.abclient.postfilter;

public class ChZero {
    public static byte[] process(byte[] array) {
        return array;
    }
}