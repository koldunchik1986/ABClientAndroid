package ru.neverlands.abclient.postfilter;

public class SlotsJs {
    public static byte[] process(byte[] array) {
        return array;
    }
}