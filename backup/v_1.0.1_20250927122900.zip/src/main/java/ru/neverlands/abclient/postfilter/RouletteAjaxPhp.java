package ru.neverlands.abclient.postfilter;

import ru.neverlands.abclient.utils.AppVars;
import ru.neverlands.abclient.utils.Chat;
import ru.neverlands.abclient.utils.Russian;

public class RouletteAjaxPhp {
    public static byte[] process(byte[] array) {
        String html = Russian.getString(array);
        String[] args = html.split("@");

        if (args.length > 2 && args[0].equals("OK")) {
            final String message = "Рулетка: " + args[1];
            // В полноценной реализации это должно проходить через ViewModel
            if (AppVars.MainWebView != null) {
                android.webkit.WebView webView = AppVars.MainWebView.get();
                if (webView != null) {
                    webView.post(() -> Chat.addMessageToChat(message));
                }
            }
        }

        // Версия для C# вызывает навигацию. Мы сделаем так же.
        // В конечном итоге это должно обрабатываться полноценным компонентом навигации.
        if (AppVars.MainWebView != null) {
            android.webkit.WebView webView = AppVars.MainWebView.get();
            if (webView != null) {
                webView.post(() -> {
                    webView.loadUrl("http://www.neverlands.ru/main.php?mselect=15");
                });
            }
        }

        // This filter only triggers actions, it doesn't modify the response.
        return array;
    }
}