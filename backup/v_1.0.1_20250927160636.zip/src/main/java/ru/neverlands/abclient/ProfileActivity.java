package ru.neverlands.abclient;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import ru.neverlands.abclient.databinding.ActivityProfileBinding;
import ru.neverlands.abclient.model.UserConfig;

public class ProfileActivity extends AppCompatActivity {
    private ActivityProfileBinding binding;
    private UserConfig profile;
    private String originalUserNick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String profileId = getIntent().getStringExtra("profile_id");
        if (!TextUtils.isEmpty(profileId)) {
            java.util.List<UserConfig> profiles = UserConfig.loadAllProfiles(this);
            for (UserConfig p : profiles) {
                if (p.id.equals(profileId)) {
                    profile = p;
                    break;
                }
            }
            if (profile == null) {
                // ID был передан, но профиль не найден. Создаем новый.
                profile = new UserConfig();
                Toast.makeText(this, "Ошибка: профиль для редактирования не найден.", Toast.LENGTH_SHORT).show();
            }
        } else {
            profile = new UserConfig();
        }

        originalUserNick = profile.UserNick; // Сохраняем исходное имя

        binding.usernameEditText.setText(profile.UserNick);
        binding.passwordEditText.setText(profile.UserPassword);
        binding.flashPasswordEditText.setText(profile.UserPasswordFlash);
        binding.autoLogonCheckBox.setChecked(profile.UserAutoLogon);
        binding.useProxyCheckBox.setChecked(profile.UseProxy);
        binding.proxyAddressEditText.setText(profile.ProxyAddress);
        binding.proxyUsernameEditText.setText(profile.ProxyUserName);
        binding.proxyPasswordEditText.setText(profile.ProxyPassword);

        binding.saveButton.setOnClickListener(v -> saveProfile());
    }

    private void saveProfile() {
        String newUsername = binding.usernameEditText.getText().toString().trim();
        if (newUsername.isEmpty()) {
            Toast.makeText(this, "Имя пользователя не может быть пустым", Toast.LENGTH_SHORT).show();
            return;
        }

        // Если имя пользователя было изменено, нужно удалить старый файл профиля
        if (originalUserNick != null && !originalUserNick.isEmpty() && !originalUserNick.equals(newUsername)) {
            UserConfig oldProfile = new UserConfig();
            oldProfile.UserNick = originalUserNick;
            oldProfile.delete();
        }

        profile.UserNick = newUsername;
        profile.UserPassword = binding.passwordEditText.getText().toString().trim();
        profile.UserPasswordFlash = binding.flashPasswordEditText.getText().toString().trim();
        profile.UserAutoLogon = binding.autoLogonCheckBox.isChecked();
        profile.UseProxy = binding.useProxyCheckBox.isChecked();
        profile.ProxyAddress = binding.proxyAddressEditText.getText().toString().trim();
        profile.ProxyUserName = binding.proxyUsernameEditText.getText().toString().trim();
        profile.ProxyPassword = binding.proxyPasswordEditText.getText().toString().trim();

        profile.save(this);

        setResult(RESULT_OK);
        finish();
    }
}
