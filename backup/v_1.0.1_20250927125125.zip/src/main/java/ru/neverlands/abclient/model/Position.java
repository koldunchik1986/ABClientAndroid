package ru.neverlands.abclient.model;

public class Position {
    public String RegNum;
    public int X;
    public int Y;
}
