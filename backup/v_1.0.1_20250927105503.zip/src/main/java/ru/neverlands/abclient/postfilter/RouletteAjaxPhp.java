package ru.neverlands.abclient.postfilter;

import ru.neverlands.abclient.utils.AppVars;
import ru.neverlands.abclient.utils.Chat;
import ru.neverlands.abclient.utils.Russian;

public class RouletteAjaxPhp {
    public static byte[] process(byte[] array) {
        String html = Russian.getString(array);
        String[] args = html.split("@");

        if (args.length > 2 && args[0].equals("OK")) {
            final String message = "Рулетка: " + args[1];
            // In a real implementation, this would go through a ViewModel
            if (AppVars.MainWebView != null) {
                AppVars.MainWebView.post(() -> Chat.addMessageToChat(message));
            }
        }

        // The C# version triggers a navigation. We will do the same.
        // This should eventually be handled by a proper navigation component.
        if (AppVars.MainWebView != null) {
            AppVars.MainWebView.post(() -> {
                AppVars.MainWebView.loadUrl("http://www.neverlands.ru/main.php?mselect=15");
            });
        }

        // This filter only triggers actions, it doesn't modify the response.
        return array;
    }
}