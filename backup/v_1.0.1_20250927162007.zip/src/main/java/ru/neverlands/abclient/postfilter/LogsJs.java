package ru.neverlands.abclient.postfilter;

public class LogsJs {
    public static byte[] process(byte[] array) {
        return array;
    }
}